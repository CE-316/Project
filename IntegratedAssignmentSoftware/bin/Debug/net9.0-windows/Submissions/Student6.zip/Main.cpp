#include <iostream>

int main(int argc, char* argv[]) {
    for (int i = 1; i < argc; ++i) {  // Start from 1 to skip the program name
        std::cout << argv[i] << std::endl;
    }
    return 0;
}

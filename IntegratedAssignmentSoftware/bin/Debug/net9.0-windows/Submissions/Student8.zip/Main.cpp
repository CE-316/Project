#include <iostream>

int main(int argc, char* argv[]) {
    for (int i = 1; i < argc; ++i) {  // Skip argv[0] which is the program name
        std::cout << argv[i] << std::endl;
    }
    return 0;
}
